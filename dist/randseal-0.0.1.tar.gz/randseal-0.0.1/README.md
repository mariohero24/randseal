# randseal
Simple package that produces a seal image. The image is then output as a `discord.File` for Pycord.